<?php

class ItemsMaster_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('DirectLink');
    }

    public function getItems($keyword = '', $limit = 10, $offset = 0, $kdkategori = array(), $oderBy = 0)
    {
        $this->db->select('itemmaster.id_barang, itemmaster.slug_barang, itemmaster.gambar1, itemmaster.judul, itemmaster.harga, itemmaster.diskon');
        $this->db->select("(SELECT CAST(SUM(cabang_item_stok.qty_stok) > 0 AS UNSIGNED) FROM cabang_item_stok WHERE cabang_item_stok.idbarang = itemmaster.id_barang) AS status_stok");
        $this->db->from('itemmaster');
        $this->db->like('itemmaster.judul', $keyword); // Pencarian berdasarkan judul

        // Filter berdasarkan kdkategori jika kdkategori tidak kosong
        if (!empty($kdkategori)) {
            $this->db->where_in('itemmaster.kdkategori', $kdkategori);
        }

        // Mengurutkan data berdasarkan id_barang secara descending (terbaru)
        switch ($oderBy) {
            case 1:
                $this->db->order_by('itemmaster.id_barang', 'DESC');
                break;
            case 2:
                $this->db->order_by('itemmaster.jumlah_dibeli', 'DESC');
                break;
        }


        // Membatasi jumlah data yang diambil dan offset
        $this->db->limit($limit, $offset);

        $query = $this->db->get();
        $results = $query->result_array();

        foreach ($results as &$result) {
            $result['gambar1'] = linkImageItems() . $result['gambar1'];
            $result['harga'] = intval($result['harga']);
            $result['diskon'] = intval($result['diskon']);
            $result['status_stok'] = boolval($result['status_stok']);
        }

        return $results;
    }

    public function getNewItems($keyword = '', $limit = 10, $offset = 0, $kdkategori = array())
    {
        $results = $this->getItems($keyword, $limit, $offset, $kdkategori, 1);

        return $results;
    }

    public function getBestSaller($keyword = '', $limit = 10, $offset = 0, $kdkategori = array())
    {
        $results = $this->getItems($keyword, $limit, $offset, $kdkategori, 2);

        return $results;
    }
}
