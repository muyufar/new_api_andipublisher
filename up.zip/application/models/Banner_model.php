<?php

class Banner_model extends CI_Model
{
    public function getBunner()
    {
        $query =  $this->db->select('idbanner, nama_banner, gambar_banner, link_banner')->from('promo_banner')
            ->where('tgl_exp_banner >', date('Y-m-d'))
            ->order_by('tgl_exp_banner', 'DESC')
            ->get();

        $row = $query->result_array();

        return $row;
    }
}
