<?php

function linkImageProfile()
{
    return 'https://andipublisher.com/images/user/profile/';
}

function linkImageItems()
{
    return 'https://andipublisher.com/images/barang/';
}

function linkImageBanner()
{
    return 'https://dev.andipublisher.com/images/banner/';
}
